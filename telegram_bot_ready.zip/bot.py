import telebot
import os

TOKEN = os.getenv("BOT_TOKEN")
OWNER_ID = int(os.getenv("OWNER_ID"))

bot = telebot.TeleBot(TOKEN)

@bot.message_handler(func=lambda m: True)
def forward_to_owner(message):
    bot.forward_message(OWNER_ID, message.chat.id, message.message_id)

@bot.message_handler(func=lambda m: m.chat.id == OWNER_ID)
def reply_to_user(message):
    if message.reply_to_message and message.reply_to_message.forward_from:
        user_id = message.reply_to_message.forward_from.id
        bot.send_message(user_id, message.text)

bot.polling(none_stop=True)
